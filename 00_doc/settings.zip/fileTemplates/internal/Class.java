#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**  
  * ${description}
  * @author zxh
  * @date ${YEAR}年 ${MONTH}月${DAY}日 ${HOUR}:${MINUTE}:${SECOND}
  */
public class ${NAME} {
}
